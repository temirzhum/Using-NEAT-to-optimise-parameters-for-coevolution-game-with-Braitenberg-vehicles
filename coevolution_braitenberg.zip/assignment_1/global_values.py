catched_pray=0
win_pray=0
